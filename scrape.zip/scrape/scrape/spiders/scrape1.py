import scrapy
from ..items import ScrapeItem

class QuoteSpider(scrapy.Spider):
    name='shop'
    start_urls=['https://www.midsouthshooterssupply.com/dept/reloading/primers?currentpage=1']
    
    def parse(self,response):
        items= ScrapeItem()
        products=response.css('.product')
        for product in products:
            shoplist= product.css('a.catalog-item-name::text')[0].extract()
            prices =product.css('.price-rating-container .price span::text')[0].extract()
            oos =[False if (product.css('.product .out-of-stock::text')[0].extract())=='Out of Stock' else True][0]
            manufacturer= product.css('.catalog-item-brand::text')[0].extract()
            items['shoplist']=shoplist
            items['prices']=prices
            items['oos']=oos
            items['manufacturer']= manufacturer
            yield items
       